package edu.upc.prop.lab.s1;

/**
 *
 * @author bernat
 */
public class Gos extends Mascota {
    
    public Gos(int pId,String pNom, int pEdat , String pRaca, boolean pVacunat){
        super(pId, pNom, pEdat,pRaca, pVacunat);        
    }
    
}
