package edu.upc.prop.lab.s1;

/**
 *
 * @author bernat
 */
public class Gat extends Mascota{
    
     public Gat(int pId, String pNom, int pEdat , String pRaca, boolean pVacunat){

        super(pId, pNom, pEdat,pRaca, pVacunat);
        
    }
    
}
